package ru.ktozdesgus.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import org.json.JSONArray

private val Bg = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Muted = Color(0xFF9A9DA7)
private val Accent = Color(0xFFE8B85B)
private val White = Color(0xFFF4F3EF)

data class Deck(val title: String, val color: Color, val questions: List<String>)
private val decks = listOf(
    Deck("БЕЛАЯ", Color(0xFFEAE8E1), listOf(
        "Насколько ты любишь спонтанные поездки?","Какой суперспособностью ты хотел бы обладать?",
        "Насколько ты азартный человек?","Как часто ты откладываешь дела на потом?",
        "Что лучше: море или горы?","Насколько легко тебя рассмешить?","Ты скорее сова или жаворонок?",
        "Какой жанр кино ты выбираешь чаще всего?","Насколько ты любишь знакомиться с новыми людьми?",
        "Что важнее в отпуске: комфорт или впечатления?","Насколько ты умеешь хранить секреты?",
        "Как часто ты принимаешь решения импульсивно?","Насколько ты терпеливый человек?",
        "Ты предпочитаешь планировать или действовать по ситуации?","Какой бытовой навык у тебя развит лучше всего?",
        "Насколько ты зависим от телефона?","Ты легко меняешь своё мнение?","Как часто ты опаздываешь?",
        "Насколько ты любишь настольные игры?","Что выберешь: вечер дома или шумную вечеринку?",
        "Насколько ты конкурентный человек?","Ты больше доверяешь логике или интуиции?",
        "Насколько хорошо ты ориентируешься в незнакомом городе?","Как часто ты пробуешь что-то новое?",
        "Ты умеешь признавать свои ошибки?"
    )),
    Deck("СЕРАЯ", Color(0xFF9298A5), listOf(
        "Насколько ты ревнивый человек?","Ты когда-нибудь притворялся, что понял шутку?",
        "Насколько часто ты скрываешь настоящее настроение?","Ты способен простить серьёзную обиду?",
        "Как часто ты проверяешь чужие соцсети из любопытства?","Ты когда-нибудь завидовал близкому другу?",
        "Насколько ты склонен манипулировать в споре?","Ты легко говоришь людям неприятную правду?",
        "Как часто ты жалеешь о сказанном?","Ты скорее избегаешь конфликтов или идёшь напролом?",
        "Бывало ли, что ты дружил с человеком из выгоды?","Насколько тебе важно чужое одобрение?",
        "Ты когда-нибудь выдавал чужую идею за свою?","Насколько ты злопамятный?",
        "Ты способен признаться в симпатии первым?","Как часто ты читаешь сообщения и не отвечаешь?",
        "Ты когда-нибудь специально вызывал ревность?","Насколько легко тебя задеть словами?",
        "Ты умеешь отказывать близким?","Бывало ли, что ты притворялся занятым, чтобы не встречаться?",
        "Ты чаще говоришь правду или удобную версию?","Насколько ты боишься одиночества?",
        "Ты способен первым извиниться?","Насколько ты доверяешь своему партнёру?",
        "Ты когда-нибудь возвращался к человеку, о котором жалел?"
    )),
    Deck("ЧЁРНАЯ · 18+", Color(0xFFB95C62), listOf(
        "Ты когда-нибудь флиртовал ради выгоды?","Насколько ты раскрепощён в отношениях?",
        "Ты когда-нибудь скрывал переписку от партнёра?","Смог бы ты простить эмоциональную измену?",
        "Бывало ли, что ты целовался с малознакомым человеком?","Ты когда-нибудь отправлял сообщение, о котором пожалел утром?",
        "Насколько для тебя важна сексуальная совместимость?","Ты когда-нибудь испытывал влечение к другу партнёра?",
        "Смог бы ты рассказать партнёру о своей фантазии?","Ты когда-нибудь встречался сразу с двумя людьми?",
        "Насколько ты ревнив в интимных вопросах?","Бывало ли, что ты изображал удовольствие?",
        "Ты когда-нибудь возвращался к бывшему ради близости?","Насколько легко ты говоришь о своих желаниях?",
        "Смог бы ты начать отношения без обязательств?","Ты когда-нибудь нарушал обещание верности?",
        "Насколько важна для тебя инициатива партнёра?","Ты когда-нибудь скрывал свой реальный опыт отношений?",
        "Смог бы ты признаться в случайной измене?","Насколько ты открыт к экспериментам в паре?",
        "Ты когда-нибудь флиртовал с кем-то, будучи в отношениях?","Что для тебя сложнее: отказать или получить отказ?",
        "Ты когда-нибудь жалел о близости с человеком?","Насколько для тебя важна разница в возрасте?",
        "Ты способен прямо обсудить границы в отношениях?"
    ))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GameApp() }
    }
}

@Composable
fun GameApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("gus", 0) }
    var screen by remember { mutableStateOf("home") }
    var deckIndex by remember { mutableIntStateOf(0) }
    var playersText by remember { mutableStateOf("5") }
    var playerNames by remember { mutableStateOf(listOf("Игрок 1","Игрок 2","Игрок 3","Игрок 4","Игрок 5")) }
    var goose by remember { mutableIntStateOf(0) }
    var order by remember { mutableIntStateOf(0) }
    var revealed by remember { mutableStateOf(false) }
    var question by remember { mutableStateOf("") }
    var custom by remember { mutableStateOf("") }
    var customQuestions by remember { mutableStateOf(prefs.getString("custom", "") ?: "") }
    var showRules by remember { mutableStateOf(false) }
    val deck = decks[deckIndex]
    val allQuestions = remember(deckIndex, customQuestions) {
        deck.questions + customQuestions.split("\n").map { it.trim() }.filter { it.isNotBlank() }
    }
    val totalPlayers = playerNames.size.coerceAtLeast(3)

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent, onBackground = White,
        onSurface = White, secondary = Muted
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ГУСЬ / PARTY GAME", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.weight(1f))
                    Text("🪿", fontSize = 25.sp)
                }
                Spacer(Modifier.height(18.dp))
                when (screen) {
                    "home" -> {
                        Spacer(Modifier.height(35.dp))
                        Text("Кто здесь\nгусь?", fontSize = 48.sp, lineHeight = 52.sp, fontWeight = FontWeight.Black, color = White)
                        Spacer(Modifier.height(12.dp))
                        Text("Один не знает вопроса.\nОстальные знают — вычислите чужака.", color = Muted, fontSize = 16.sp, lineHeight = 23.sp)
                        Spacer(Modifier.height(34.dp))
                        Text("ВЫБЕРИ КОЛОДУ", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(12.dp))
                        decks.forEachIndexed { i, d ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(16.dp))
                                .clickable { deckIndex = i }.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(9.dp).background(d.color, RoundedCornerShape(50)))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(d.title, fontWeight = FontWeight.Bold, color = White)
                                    Text("${d.questions.size} вопросов", color = Muted, fontSize = 12.sp)
                                }
                                if (deckIndex == i) Text("✓", color = Accent, fontSize = 20.sp)
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Button(onClick = { screen = "setup" }, modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                            shape = RoundedCornerShape(16.dp)) { Text("НАЧАТЬ ИГРУ", fontWeight = FontWeight.Bold) }
                        TextButton(onClick = { screen = "custom" }, modifier = Modifier.fillMaxWidth()) { Text("Свои вопросы", color = Muted) }
                        TextButton(onClick = { showRules = true }, modifier = Modifier.fillMaxWidth()) { Text("Как играть?", color = Muted) }
                    }
                    "setup" -> {
                        Header("Игроки")
                        Text("Минимум 3 участника. Передавайте телефон по кругу.", color = Muted)
                        Spacer(Modifier.height(20.dp))
                        OutlinedTextField(value = playersText, onValueChange = { v ->
                            playersText = v.filter { it.isDigit() }.take(2)
                            val n = (playersText.toIntOrNull() ?: 3).coerceIn(3, 20)
                            playerNames = List(n) { playerNames.getOrNull(it) ?: "Игрок ${it+1}" }
                        }, label = { Text("Количество игроков") }, singleLine = true)
                        Spacer(Modifier.height(14.dp))
                        LazyColumn(Modifier.weight(1f)) {
                            items(playerNames.size) { i ->
                                OutlinedTextField(value = playerNames[i], onValueChange = { v ->
                                    playerNames = playerNames.toMutableList().also { it[i] = v }
                                }, label = { Text("Игрок ${i+1}") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
                            }
                        }
                        Button(onClick = {
                            goose = (0 until totalPlayers).random()
                            question = allQuestions.random()
                            order = 0; revealed = false; screen = "pass"
                        }, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("РАЗДАТЬ РОЛИ") }
                    }
                    "pass" -> {
                        Spacer(Modifier.height(40.dp))
                        Text("ПЕРЕДАЙТЕ ТЕЛЕФОН", color = Muted, letterSpacing = 2.sp, fontSize = 12.sp)
                        Spacer(Modifier.height(25.dp))
                        Text(playerNames.getOrNull(order) ?: "Игрок", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Text("Убедитесь, что остальные не смотрят на экран.", color = Muted)
                        Spacer(Modifier.height(30.dp))
                        Button(onClick = { revealed = true }, modifier = Modifier.fillMaxWidth().height(58.dp)) { Text("ПОСМОТРЕТЬ СВОЮ РОЛЬ") }
                        if (revealed) {
                            Spacer(Modifier.height(22.dp))
                            if (order == goose) {
                                Box(Modifier.fillMaxWidth().background(Color(0xFF382226), RoundedCornerShape(18.dp)).padding(22.dp)) {
                                    Column {
                                        Text("ТЫ — ГУСЬ 🪿", color = Color(0xFFFF858B), fontWeight = FontWeight.Black, fontSize = 23.sp)
                                        Text("Ты не знаешь секретный вопрос. Слушай ответы и не выдавай себя.", color = White)
                                    }
                                }
                            } else {
                                Box(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(22.dp)) {
                                    Column {
                                        Text("ТВОЙ ВОПРОС", color = Accent, fontSize = 12.sp, letterSpacing = 2.sp)
                                        Spacer(Modifier.height(9.dp))
                                        Text(question, color = White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                                        Spacer(Modifier.height(8.dp))
                                        Text("Не показывай вопрос другим игрокам.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(20.dp))
                            Button(onClick = {
                                revealed = false
                                if (order < totalPlayers - 1) order++ else screen = "round"
                            }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                                Text(if (order < totalPlayers - 1) "ПЕРЕДАТЬ СЛЕДУЮЩЕМУ" else "К НАЧАЛУ РАУНДА")
                            }
                        }
                    }
                    "round" -> {
                        Spacer(Modifier.height(28.dp))
                        Text("ВСЕ ГОТОВЫ?", color = Accent, letterSpacing = 2.sp, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("Время обсуждать", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Text("По очереди отвечайте на вопрос своими словами. Гусь должен догадаться, о чём речь, а остальные — не выдать вопрос слишком явно.", color = Muted, fontSize = 15.sp, lineHeight = 22.sp)
                        Spacer(Modifier.height(25.dp))
                        Box(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(20.dp)) {
                            Column {
                                Text("УЧАСТНИКИ", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                                Spacer(Modifier.height(10.dp))
                                playerNames.forEachIndexed { i, name -> Text("${i+1}. $name", color = White, modifier = Modifier.padding(vertical = 3.dp)) }
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        Button(onClick = { screen = "vote" }, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("ПЕРЕЙТИ К ГОЛОСОВАНИЮ") }
                    }
                    "vote" -> {
                        Spacer(Modifier.height(25.dp))
                        Text("КТО ГУСЬ?", fontSize = 35.sp, fontWeight = FontWeight.Black)
                        Text("Обсудите и выберите подозреваемого. Затем откройте ответ.", color = Muted)
                        Spacer(Modifier.height(20.dp))
                        var chosen by remember { mutableIntStateOf(-1) }
                        playerNames.forEachIndexed { i, name ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel, RoundedCornerShape(12.dp))
                                .clickable { chosen = i }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(name, Modifier.weight(1f), color = White)
                                RadioButton(selected = chosen == i, onClick = { chosen = i })
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        var result by remember { mutableStateOf(false) }
                        if (result) {
                            Text(if (chosen == goose) "Верно! ${playerNames[goose]} был гусём 🪿" else "Не угадали! Гусь — ${playerNames[goose]} 🪿",
                                color = if (chosen == goose) Color(0xFF8ED6A5) else Color(0xFFFF858B), fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text(if (chosen == goose) "Команда вычислила гуся." else "Гусь остался нераскрытым.", color = Muted)
                        }
                        Button(onClick = { result = true }, enabled = chosen >= 0 && !result,
                            modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("РАСКРЫТЬ ГУСЯ") }
                        TextButton(onClick = { screen = "home" }, modifier = Modifier.fillMaxWidth()) { Text("Новая игра", color = Muted) }
                    }
                    "custom" -> {
                        Header("Свои вопросы")
                        Text("Добавляй вопросы — по одному на строку. Они попадут в выбранную колоду.", color = Muted)
                        Spacer(Modifier.height(15.dp))
                        OutlinedTextField(value = custom, onValueChange = { custom = it }, modifier = Modifier.fillMaxWidth().weight(1f),
                            label = { Text("Новый вопрос") }, placeholder = { Text("Введи вопросы, каждый с новой строки") })
                        Button(onClick = {
                            customQuestions = (customQuestions.lines() + custom.lines()).map { it.trim() }.filter { it.isNotBlank() }.distinct().joinToString("\n")
                            prefs.edit().putString("custom", customQuestions).apply()
                            custom = ""; screen = "home"
                        }, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("СОХРАНИТЬ") }
                        TextButton(onClick = { screen = "home" }, modifier = Modifier.fillMaxWidth()) { Text("Назад", color = Muted) }
                    }
                }
            }
            if (showRules) AlertDialog(onDismissRequest = { showRules = false },
                title = { Text("Как играть?") },
                text = { Text("1. Выберите колоду и добавьте игроков.\n2. Передавайте телефон по кругу: каждый тайно смотрит свою роль.\n3. Все, кроме гуся, увидят один вопрос.\n4. По очереди отвечайте, не называя вопрос напрямую.\n5. Обсудите ответы и проголосуйте, кто гусь.\n6. Откройте ответ. Если хотите, сыграйте ещё раз!") },
                confirmButton = { TextButton(onClick = { showRules = false }) { Text("Понятно") } },
                containerColor = Panel, titleContentColor = White, textContentColor = Muted)
        }
    }
}

@Composable
private fun Header(title: String) {
    Spacer(Modifier.height(24.dp))
    Text(title, fontSize = 34.sp, fontWeight = FontWeight.Bold, color = White)
    Spacer(Modifier.height(10.dp))
}
